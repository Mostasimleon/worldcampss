export const WORD_CAMP_API =
  "https://central.wordcamp.org/?rest_route=/wp/v2/wordcamps&_embed&per_page=100&page";
