import React from "react";
import ReactDOM from "react-dom";
//Import App
import App from "./App";

ReactDOM.render(<App />, document.querySelector("#root"));
